<?php
session_start();
require 'config/db.php';

// Проверка авторизации
if(!isset($_SESSION['user_id'])){
    header('Location: login.php');
    exit;
}

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $image = $_FILES['image'] ?? null;
    $filename = null;

    if(!$title || !$content){
        $error = "Введите заголовок и текст поста";
    } else {
        if($image && $image['tmp_name']){
            $ext = pathinfo($image['name'], PATHINFO_EXTENSION);
            $filename = 'uploads/'.time().'_'.rand(1000,9999).'.'.$ext;
            move_uploaded_file($image['tmp_name'], $filename);
        }

        $stmt = $pdo->prepare("INSERT INTO posts (user_id,title,content,image,status,created_at) VALUES (?,?,?,?, 'pending', NOW())");
        $stmt->execute([$_SESSION['user_id'],$title,$content,$filename]);

        $success = "Пост отправлен на модерацию";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Создать пост</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f5f7fa; font-family:'Segoe UI',sans-serif; }
.container { max-width:600px; margin-top:50px; }
.card { padding:30px; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.1); }
.btn-primary { border-radius:30px; }
.form-control, input[type="file"] { border-radius:10px; margin-bottom:15px; }
.alert { border-radius:10px; }
</style>
</head>
<body>
<div class="container">
<div class="card">
<h2>Создать пост</h2>

<?php if($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>
<?php if(isset($success)): ?>
<div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
<input type="text" name="title" placeholder="Заголовок" class="form-control" required>
<textarea name="content" placeholder="Текст поста" class="form-control" rows="6" required></textarea>
<input type="file" name="image" class="form-control">
<button type="submit" class="btn btn-primary">Отправить на модерацию</button>
</form>

</div>
</div>
</body>
</html>