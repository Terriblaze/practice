<?php
session_start();
require 'config/db.php';

/* Пагинация и поиск */
$limit = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$offset = ($page-1)*$limit;

/* WHERE для постов */
$where = "posts.status='approved'";
$params = [];
if($search){
    $where .= " AND posts.title LIKE ?";
    $params[] = "%$search%";
}

/* Получаем посты */
$sql = "
SELECT posts.*, users.username,
(SELECT COUNT(*) FROM likes WHERE likes.post_id=posts.id) as likes_count
FROM posts
LEFT JOIN users ON posts.user_id = users.id
WHERE $where
ORDER BY posts.created_at DESC
LIMIT $limit OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$posts = $stmt->fetchAll();

/* Кол-во постов для пагинации */
$count_sql = "SELECT COUNT(*) FROM posts WHERE $where";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total = $stmt->fetchColumn();
$pages = ceil($total/$limit);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Мой блог | Современные статьи</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<style>
:root {
    --primary: #6366f1;
    --primary-dark: #4f46e5;
    --secondary: #64748b;
    --dark: #0f172a;
    --light: #f8fafc;
    --success: #10b981;
    --danger: #ef4444;
    --warning: #f59e0b;
    --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

* {
    transition: all 0.3s ease;
}

body {
    background: linear-gradient(135deg, #f5f7fa 0%, #e9eef5 100%);
    font-family: 'Inter', 'Segoe UI', sans-serif;
    min-height: 100vh;
    margin: 0;
    color: var(--dark);
}

/* Навбар */
.navbar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
    padding: 1rem 2rem;
    position: sticky;
    top: 0;
    z-index: 1000;
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
}

.navbar-brand {
    font-weight: 800;
    font-size: 1.8rem;
    background: var(--gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.5px;
}

.navbar .btn {
    border-radius: 50px;
    padding: 0.5rem 1.5rem;
    font-weight: 500;
    font-size: 0.95rem;
}

.btn-outline-success {
    border: 2px solid var(--success);
    color: var(--success);
}

.btn-outline-success:hover {
    background: var(--success);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -10px var(--success);
}

.btn-outline-primary {
    border: 2px solid var(--primary);
    color: var(--primary);
}

.btn-outline-primary:hover {
    background: var(--primary);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -10px var(--primary);
}

.btn-outline-danger {
    border: 2px solid var(--danger);
    color: var(--danger);
}

.btn-outline-danger:hover {
    background: var(--danger);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -10px var(--danger);
}

/* Хедер блога */
.blog-header {
    text-align: center;
    padding: 60px 20px 40px;
    margin-bottom: 30px;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border-radius: 40px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.05);
}

.blog-header h1 {
    font-size: 3.5rem;
    font-weight: 800;
    background: var(--gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 1rem;
    letter-spacing: -1px;
}

.blog-header p {
    font-size: 1.2rem;
    color: var(--secondary);
    font-weight: 400;
}

/* Поиск */
.search-box {
    max-width: 600px;
    margin: 30px auto 0;
}

.search-box .input-group {
    background: white;
    border-radius: 60px;
    padding: 5px;
    box-shadow: 0 10px 30px rgba(99, 102, 241, 0.1);
    border: 1px solid rgba(99, 102, 241, 0.2);
}

.search-box .form-control {
    border: none;
    padding: 0.9rem 1.5rem;
    font-size: 1rem;
    background: transparent;
    border-radius: 60px 0 0 60px;
}

.search-box .form-control:focus {
    box-shadow: none;
    outline: none;
}

.search-box .btn {
    border-radius: 60px;
    padding: 0.9rem 2rem;
    background: var(--gradient);
    border: none;
    color: white;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.search-box .btn:hover {
    transform: scale(1.02);
    box-shadow: 0 10px 20px rgba(99, 102, 241, 0.3);
}

/* Кнопка создания поста */
.create-btn {
    display: inline-block;
    padding: 12px 30px;
    background: var(--gradient);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    font-size: 1rem;
    margin-bottom: 40px;
    box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2);
}

.create-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 20px 30px rgba(99, 102, 241, 0.3);
    color: white;
}

.create-btn i {
    margin-right: 8px;
}

/* Карточки постов */
.post-card {
    border: none;
    border-radius: 24px;
    overflow: hidden;
    background: white;
    box-shadow: 0 20px 35px -10px rgba(0, 0, 0, 0.1);
    height: 100%;
    display: flex;
    flex-direction: column;
    position: relative;
}

.post-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 30px 45px -10px rgba(99, 102, 241, 0.2);
}

.post-img {
    height: 220px;
    width: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.post-card:hover .post-img {
    transform: scale(1.05);
}

.card-body {
    padding: 1.8rem;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.card-title {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 1rem;
    line-height: 1.4;
}

.card-title a {
    color: var(--dark);
    text-decoration: none;
    transition: color 0.3s;
}

.card-title a:hover {
    color: var(--primary);
}

.author {
    font-size: 0.9rem;
    color: var(--secondary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
}

.author i {
    margin-right: 5px;
    color: var(--primary);
}

.author a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
    margin-left: 5px;
}

.author a:hover {
    text-decoration: underline;
}

.post-excerpt {
    color: #475569;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    flex-grow: 1;
}

/* Кнопки в карточке */
.card-footer {
    background: transparent;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
    padding: 1rem 1.8rem 1.8rem;
}

.btn-read {
    background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
    color: var(--dark);
    border: none;
    border-radius: 50px;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
}

.btn-read:hover {
    background: var(--gradient);
    color: white;
    transform: translateX(5px);
}

.btn-like {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger);
    border: none;
    border-radius: 50px;
    padding: 0.6rem 1.2rem;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
}

.btn-like:hover {
    background: var(--danger);
    color: white;
    transform: scale(1.05);
}

.btn-like i {
    margin-right: 5px;
}

.views {
    color: var(--secondary);
    font-size: 0.9rem;
    display: flex;
    align-items: center;
}

.views i {
    margin-right: 5px;
    color: var(--primary);
}

/* Пагинация */
.pagination {
    gap: 8px;
    margin-top: 50px;
    margin-bottom: 30px;
}

.page-link {
    border: none;
    border-radius: 50px !important;
    padding: 0.8rem 1.2rem;
    font-weight: 600;
    color: var(--secondary);
    background: white;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.page-item.active .page-link {
    background: var(--gradient);
    color: white;
    transform: scale(1.05);
}

.page-link:hover {
    background: var(--primary);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(99, 102, 241, 0.2);
}

/* Анимации */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.post-card {
    animation: fadeInUp 0.6s ease backwards;
}

.post-card:nth-child(1) { animation-delay: 0.1s; }
.post-card:nth-child(2) { animation-delay: 0.2s; }
.post-card:nth-child(3) { animation-delay: 0.3s; }
.post-card:nth-child(4) { animation-delay: 0.4s; }
.post-card:nth-child(5) { animation-delay: 0.5s; }
.post-card:nth-child(6) { animation-delay: 0.6s; }

/* Адаптивность */
@media (max-width: 768px) {
    .navbar {
        padding: 1rem;
    }
    
    .blog-header h1 {
        font-size: 2.5rem;
    }
    
    .blog-header p {
        font-size: 1rem;
    }
    
    .search-box .btn {
        padding: 0.9rem 1.5rem;
    }
    
    .post-card {
        margin-bottom: 20px;
    }
}

/* Счетчик лайков */
.likes-count {
    font-weight: 600;
    margin-left: 5px;
}

/* Бейдж администратора */
.admin-badge {
    background: var(--gradient);
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 50px;
    font-size: 0.8rem;
    font-weight: 600;
    margin-left: 10px;
}
</style>
</head>
<body>

<!-- Навигация -->
<nav class="navbar d-flex justify-content-between align-items-center">
    <a class="navbar-brand" href="blog.php">
        <i class="bi bi-pencil-square"></i> Мой Блог
    </a>
    <div class="d-flex align-items-center gap-2">
        <?php if(isset($_SESSION['user_id'])): ?>
            <div class="d-flex align-items-center">
                <span class="me-3 fw-semibold">
                    <i class="bi bi-person-circle"></i> 
                    <?= htmlspecialchars($_SESSION['username']) ?>
                </span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">
                        <i class="bi bi-shield-check"></i> Admin
                    </span>
                    <a href="admin/index.php" class="btn btn-outline-primary me-2">
                        <i class="bi bi-gear"></i> Админ
                    </a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-outline-danger">
                    <i class="bi bi-box-arrow-right"></i> Выйти
                </a>
            </div>
        <?php else: ?>
            <a href="login.php" class="btn btn-outline-success">
                <i class="bi bi-box-arrow-in-right"></i> Войти
            </a>
            <a href="register.php" class="btn btn-outline-primary">
                <i class="bi bi-person-plus"></i> Регистрация
            </a>
        <?php endif; ?>
    </div>
</nav>

<div class="container mt-4">

<!-- Хедер -->
<div class="blog-header">
    <h1>📝 Мой блог</h1>
    
    
    <!-- Поиск -->
    <form method="GET" class="search-box">
        <div class="input-group">
            <input type="text" name="search" class="form-control" 
                   placeholder="Что будем искать?" 
                   value="<?= htmlspecialchars($search) ?>">
            <button class="btn" type="submit">
                <i class="bi bi-search"></i> Найти
            </button>
        </div>
    </form>
</div>

<!-- Кнопка создания поста для авторизованных -->
<?php if(isset($_SESSION['user_id'])): ?>
    <div class="text-center">
        <a href="blog_add.php" class="create-btn">
            <i class="bi bi-plus-circle"></i> Создать новый пост
        </a>
    </div>
<?php endif; ?>

<!-- Сетка постов -->
<div class="row g-4">
<?php foreach($posts as $post): ?>
    <div class="col-lg-4 col-md-6">
        <div class="post-card">
            <?php if($post['image']): ?>
                <img src="uploads/<?= $post['image'] ?>" class="post-img" alt="<?= htmlspecialchars($post['title']) ?>">
            <?php else: ?>
            
            <?php endif; ?>
            
            <div class="card-body">
                <h5 class="card-title">
                    <a href="post.php?id=<?= $post['id'] ?>">
                        <?= htmlspecialchars($post['title']) ?>
                    </a>
                </h5>
                
                <div class="author">
                    <i class="bi bi-person"></i>
                    Автор:
                    <a href="author.php?id=<?= $post['user_id'] ?>">
                        <?= htmlspecialchars($post['username']) ?>
                    </a>
                </div>
                
                <p class="post-excerpt">
                    <?= mb_substr(strip_tags($post['content']), 0, 120) ?>...
                </p>
            </div>
            
            <div class="card-footer">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-2">
                        <a href="post.php?id=<?= $post['id'] ?>" class="btn-read">
                            <i class="bi bi-book"></i> Читать
                        </a>
                        <a href="like_post.php?id=<?= $post['id'] ?>" class="btn-like">
                            <i class="bi bi-heart-fill"></i>
                            <span class="likes-count"><?= $post['likes_count'] ?></span>
                        </a>
                    </div>
                    <div class="views">
                        <i class="bi bi-eye"></i>
                        <?= number_format($post['views'] ?? 0) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
</div>

<!-- Пагинация -->
<?php if($pages > 1): ?>
<nav>
    <ul class="pagination justify-content-center">
        <?php for($i = 1; $i <= $pages; $i++): ?>
            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>">
                    <?= $i ?>
                </a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>

<!-- Сообщение, если постов нет -->
<?php if(empty($posts)): ?>
    <div class="text-center py-5">
        <i class="bi bi-emoji-frown" style="font-size: 4rem; color: var(--secondary);"></i>
        <h3 class="mt-3" style="color: var(--secondary);">Постов не найдено</h3>
        <?php if($search): ?>
            <p>По вашему запросу "<?= htmlspecialchars($search) ?>" ничего не найдено</p>
            <a href="blog.php" class="btn btn-outline-primary mt-3">
                <i class="bi bi-arrow-left"></i> Вернуться к блогу
            </a>
        <?php endif; ?>
    </div>
<?php endif; ?>

</div>

<!-- Bootstrap Icons и JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>