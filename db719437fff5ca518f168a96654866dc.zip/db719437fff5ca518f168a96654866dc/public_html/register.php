<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require 'config/db.php';

$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if(!$username || !$email || !$password || !$password_confirm){
        $error = "Все поля обязательны";
    } elseif($password !== $password_confirm){
        $error = "Пароли не совпадают";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
        $stmt->execute([$email]);
        if($stmt->fetch()){
            $error = "Пользователь с этим email уже существует";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users (username,email,password_hash,role) 
                VALUES (?,?,?, 'user')
            ");
            $stmt->execute([$username, $email, $hash]);

            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['username'] = $username;

            header('Location: blog.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Регистрация</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: #f5f7fa; font-family: 'Segoe UI', sans-serif; }
.container { max-width: 450px; margin-top: 80px; }
.card { padding: 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
h2 { margin-bottom: 25px; font-weight: 700; text-align: center; }
.btn-primary { border-radius: 30px; width: 100%; padding: 10px; }
.form-control { border-radius: 10px; margin-bottom: 15px; }
.alert { border-radius: 10px; }
</style>
</head>
<body>

<div class="container">
<div class="card">
<h2>Регистрация</h2>

<?php if($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">
    <input type="text" name="username" placeholder="Имя пользователя" class="form-control" required>
    <input type="email" name="email" placeholder="Email" class="form-control" required>
    <input type="password" name="password" placeholder="Пароль" class="form-control" required>
    <input type="password" name="password_confirm" placeholder="Повторите пароль" class="form-control" required>
    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
</form>

<p class="mt-3 text-center">Уже есть аккаунт? <a href="login.php">Войти</a></p>
</div>
</div>

</body>
</html>