<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require 'config/db.php';

$error = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if(!$email || !$password){
        $error = "Введите email и пароль";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if($user && password_verify($password, $user['password_hash'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role']; // ✅ сохраняем роль

            header('Location: blog.php');
            exit;
        } else {
            $error = "Неправильный email или пароль";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Вход</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: #f5f7fa; font-family: 'Segoe UI', sans-serif; }
.container { max-width: 400px; margin-top: 80px; }
.card { padding: 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
h2 { margin-bottom: 25px; font-weight: 700; text-align: center; }
.btn-primary { border-radius: 30px; width: 100%; padding: 10px; }
.form-control { border-radius: 10px; margin-bottom: 15px; }
.alert { border-radius: 10px; }
</style>
</head>
<body>
<div class="container">
<div class="card">
<h2>Вход</h2>

<?php if($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">
    <input type="email" name="email" placeholder="Email" class="form-control" required>
    <input type="password" name="password" placeholder="Пароль" class="form-control" required>
    <button type="submit" class="btn btn-primary">Войти</button>
</form>

<p class="mt-3 text-center">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
</div>
</div>
</body>
</html>