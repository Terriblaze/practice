<?php
session_start();
require '../config/db.php';

// Проверка админа
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
    header('Location: ../login.php');
    exit;
}

// Статистика
$posts = $pdo->query("SELECT COUNT(*) FROM posts")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM posts WHERE status='pending'")->fetchColumn();
$comments = $pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Админ панель</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family:'Segoe UI',sans-serif; background:#f5f7fa; margin:0; }
h1 { text-align:center; margin:30px 0; color:#333; }
.dashboard-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:25px; padding:0 40px 40px; }
.card { background:#fff; border-radius:16px; padding:30px 20px; box-shadow:0 15px 35px rgba(0,0,0,0.08); transition:0.3s; }
.card:hover { transform:translateY(-5px); box-shadow:0 25px 50px rgba(0,0,0,0.12); }
.card h3 { font-size:18px; margin-bottom:15px; color:#555; }
.card h2 { font-size:36px; color:#222; font-weight:700; }
.card.posts { border-left:5px solid #4e73df; }
.card.pending { border-left:5px solid #f6c23e; }
.card.comments { border-left:5px solid #1cc88a; }
.navbar { background:#fff; box-shadow:0 5px 15px rgba(0,0,0,0.05); padding:15px 30px; display:flex; justify-content:space-between; align-items:center; }
.navbar a { text-decoration:none; font-weight:600; color:#333; }
.navbar .btn { border-radius:30px; padding:6px 18px; }
</style>
</head>
<body>

<nav class="navbar">
    <a href="../blog.php">← Вернуться к блогу</a>
    <div>
        <span class="me-3">Привет, <?= htmlspecialchars($_SESSION['username']) ?> (Admin)</span>
        <a href="../logout.php" class="btn btn-outline-danger">Выйти</a>
    </div>
</nav>

<h1>Админ Dashboard</h1>

<div class="dashboard-grid">
    <div class="card posts">
        <h3>📝 Посты</h3>
        <h2><?= $posts ?></h2>
    </div>
    <div class="card pending">
        <h3>⏳ На модерации</h3>
        <h2><?= $pending ?></h2>
    </div>
    <div class="card comments">
        <h3>💬 Комментарии</h3>
        <h2><?= $comments ?></h2>
    </div>
</div>

</body>
</html>