<?php
session_start();
require '../config/db.php';
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){ header('Location: ../login.php'); exit; }

if(isset($_GET['id'])){
    $stmt = $pdo->prepare("UPDATE posts SET status='approved' WHERE id=?");
    $stmt->execute([$_GET['id']]);
}
header('Location: index.php');
exit;