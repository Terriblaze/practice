<?php
session_start();
require '../config/db.php';
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){ header('Location: ../login.php'); exit; }

if(isset($_GET['id'])){
    $stmt = $pdo->prepare("UPDATE posts SET status='rejected' WHERE id=?");
    $stmt->execute([$_GET['id']]);
}
header('Location: admin_pending_posts.php');
exit;