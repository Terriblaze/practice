<?php
session_start();
require '../config/db.php';

// === Проверка на админа ===
if(!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header('Location: ../login.php');
    exit;
}

// === Получаем все посты на модерации ===
$stmt = $pdo->query("
    SELECT posts.*, users.username
    FROM posts
    LEFT JOIN users ON posts.user_id = users.id
    WHERE posts.status = 'pending'
    ORDER BY posts.created_at DESC
");
$pending_posts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Модерация постов</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family:'Segoe UI',sans-serif; background:#f5f7fa; margin:0; }
.container { max-width: 1100px; margin: 40px auto; }
h1 { text-align:center; margin-bottom:40px; color:#333; }
.card { background:#fff; border-radius:16px; padding:20px; box-shadow:0 10px 25px rgba(0,0,0,0.08); margin-bottom:20px; transition:0.3s; }
.card:hover { transform:translateY(-5px); box-shadow:0 25px 50px rgba(0,0,0,0.12); }
.card img { width:100%; height:180px; object-fit:cover; border-radius:12px; margin-bottom:15px; }
.card h5 { margin-bottom:5px; }
.card p { color:#555; }
.btn { border-radius:30px; }
.navbar { background:#fff; box-shadow:0 5px 15px rgba(0,0,0,0.05); padding:15px 30px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; }
.navbar a { text-decoration:none; font-weight:600; color:#333; }
</style>
</head>
<body>

<!-- Навигация -->
<nav class="navbar">
    <a href="admin_panel.php">← Dashboard</a>
    <div>
        <span class="me-3">Привет, <?= htmlspecialchars($_SESSION['username']) ?> (Admin)</span>
        <a href="../logout.php" class="btn btn-outline-danger">Выйти</a>
    </div>
</nav>

<div class="container">
<h1>Посты на модерации</h1>

<?php if(empty($pending_posts)): ?>
    <p class="text-center">Нет постов на модерации</p>
<?php else: ?>
    <?php foreach($pending_posts as $post): ?>
        <div class="card">
            <?php if($post['image']): ?>
                <img src="../uploads/<?= $post['image'] ?>" alt="Пост">
            <?php endif; ?>
            <h5><?= htmlspecialchars($post['title']) ?></h5>
            <p>Автор: <?= htmlspecialchars($post['username']) ?> | Дата: <?= $post['created_at'] ?></p>
            <p><?= mb_substr(strip_tags($post['content']), 0, 200) ?>...</p>
            <div class="d-flex gap-2 mt-2">
                <a href="approve_post.php?id=<?= $post['id'] ?>" class="btn btn-success btn-sm">Одобрить</a>
                <a href="reject_post.php?id=<?= $post['id'] ?>" class="btn btn-danger btn-sm">Отклонить</a>
                <a href="edit_post.php?id=<?= $post['id'] ?>" class="btn btn-primary btn-sm">Редактировать</a>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>

</body>
</html>