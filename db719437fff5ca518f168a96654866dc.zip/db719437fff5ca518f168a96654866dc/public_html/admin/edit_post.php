<?php
session_start();
require '../config/db.php';

// Проверка на админа
if(!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header('Location: ../login.php');
    exit;
}

// Получаем ID поста
if(!isset($_GET['id'])){
    header('Location: admin_pending_posts.php');
    exit;
}
$post_id = (int)$_GET['id'];

// Получаем пост
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id=? LIMIT 1");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if(!$post){
    header('Location: admin_pending_posts.php');
    exit;
}

// Обработка формы
$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'];

    if(!$title || !$content){
        $error = "Заголовок и содержание обязательны";
    } else {
        // Обновление картинки, если есть новая
        if(isset($_FILES['image']) && $_FILES['image']['tmp_name']){
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = "post_".$post_id."_".time().".".$ext;
            $target = "../uploads/".$filename;
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
            $stmt = $pdo->prepare("UPDATE posts SET title=?, content=?, status=?, image=? WHERE id=?");
            $stmt->execute([$title, $content, $status, $filename, $post_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE posts SET title=?, content=?, status=? WHERE id=?");
            $stmt->execute([$title, $content, $status, $post_id]);
        }

        header('Location: admin_pending_posts.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Редактировать пост</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family:'Segoe UI',sans-serif; background:#f5f7fa; padding:20px; }
.container { max-width:700px; margin:auto; background:#fff; padding:30px; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.1); }
h1 { text-align:center; margin-bottom:30px; }
.form-control, .form-select { border-radius:10px; margin-bottom:15px; }
.btn { border-radius:30px; }
.img-preview { max-width:100%; height:auto; margin-bottom:15px; border-radius:12px; }
.alert { border-radius:10px; }
</style>
</head>
<body>

<div class="container">
<h1>Редактировать пост</h1>

<?php if($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="title" class="form-control" placeholder="Заголовок" value="<?= htmlspecialchars($post['title']) ?>" required>
    <textarea name="content" class="form-control" placeholder="Содержание" rows="6" required><?= htmlspecialchars($post['content']) ?></textarea>

    <?php if($post['image']): ?>
        <img src="../uploads/<?= $post['image'] ?>" class="img-preview">
    <?php endif; ?>

    <input type="file" name="image" class="form-control">

    <select name="status" class="form-select" required>
        <option value="pending" <?= $post['status']=='pending'?'selected':'' ?>>На модерации</option>
        <option value="approved" <?= $post['status']=='approved'?'selected':'' ?>>Одобрено</option>
        <option value="rejected" <?= $post['status']=='rejected'?'selected':'' ?>>Отклонено</option>
    </select>

    <button type="submit" class="btn btn-primary w-100">Сохранить изменения</button>
</form>

<a href="admin_pending_posts.php" class="btn btn-outline-secondary w-100 mt-3">← Вернуться к модерации</a>
</div>

</body>
</html>